@yield("js-online")
<!--=============== SWIPER JS ===============-->
<script src="{{asset('assets/js/swiper-bundle.min.j')}}s"></script>

<!--=============== MAIN JS ===============-->
<script src="{{asset('assets/js/main.js')}}"></script>
@yield("js")
