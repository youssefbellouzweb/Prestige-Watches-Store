<?php $__env->startSection('title'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style-online'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <style>
        .hero-video {
            width: 100%;
            height: calc(100vh - var(--header-height));
            /* Adjust for header height */
            object-fit: cover;
            position: relative;
            z-index: -1;
        }

        .hero-content {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            text-align: center;
            color: white;
        }

        .video-section {
            position: relative;
            overflow: hidden;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!--==================== MAIN ====================-->
    <main class="main">
        <section class="video-section">
            <video class="hero-video" autoplay muted loop>
                <source src="<?php echo e(asset('assets/img/Rolex/videoplayback.mp4')); ?>" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            <div class="hero-content">

            </div>
        </section>

        <!--==================== FEATURED ====================-->
        <section class="featured section container" id="featured">
            <h2 class="section__title">The Clients Favourite</h2>

            <div class="featured__container grid">

                <?php if($products): ?>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <article class="featured__card">
                            <span class="featured__tag"><?php echo e($product['tag']); ?></span>

                            <img src="<?php echo e(asset($product['image'])); ?>" alt="<?php echo e($product['alt']); ?>" class="featured__img">

                            <div class="featured__data">
                                <h3 class="featured__title"><?php echo e($product['title']); ?></h3>
                                <span class="featured__price"><?php echo e($product['price']); ?></span>
                            </div>

                            <a href="<?php echo e(route('product', ['brand_slug' => $product['brand_slug'], 'slug' => $product['title']])); ?>" class="button featured__button">
                                Buy Now
                            </a>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <h1>Products not found</h1>
                <?php endif; ?>

            </div>
        </section>

    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-online'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Users.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/youssef-bellouz/Downloads/My Projects/Projects-Laravel/Prestige-Watches-Store/resources/views/Users/brand.blade.php ENDPATH**/ ?>