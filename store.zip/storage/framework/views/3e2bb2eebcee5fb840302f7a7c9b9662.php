<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('Users.layouts.main-links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>

    <?php echo $__env->make('Users.layouts.main-navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('Users.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('Users.layouts.footer-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH /home/youssef-bellouz/Downloads/My Projects/Projects-Laravel/Prestige-Watches-Store (Copy)/resources/views/Users/layouts/master.blade.php ENDPATH**/ ?>