<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('Users.layouts.main-links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>

    <?php echo $__env->make('Users.layouts.main-navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="cart" id="cart">
        <i class='bx bx-x cart__close' id="cart-close"></i>

        <h2 class="cart__title-center">My Cart</h2>

        <div class="cart__container">
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article class="cart__card">
                    <div class="cart__box">
                        <img src="<?php echo e(asset($item['image'])); ?>" alt="<?php echo e($item['alt']); ?>" class="cart__img">
                    </div>

                    <div class="cart__details">
                        <h3 class="cart__title"><?php echo e($item['title']); ?></h3>
                        <span class="cart__price"><?php echo e($item['price']); ?></span>

                        <div class="cart__amount">
                            <div class="cart__amount-content">
                                <span class="cart__amount-box">
                                    <i class='bx bx-minus'></i>
                                </span>

                                <span class="cart__amount-number">1</span>

                                <span class="cart__amount-box">
                                    <i class='bx bx-plus'></i>
                                </span>
                            </div>

                            <i class='bx bx-trash-alt cart__amount-trash'></i>
                        </div>
                    </div>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="cart__prices">
            <span class="cart__prices-item">3 items</span>
            <span class="cart__prices-total">$2880</span>
        </div>
    </div>

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('Users.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('Users.layouts.footer-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH /home/youssef-bellouz/Downloads/My Projects/Projects-Laravel/Prestige-Watches-Store/resources/views/Users/layouts/master.blade.php ENDPATH**/ ?>