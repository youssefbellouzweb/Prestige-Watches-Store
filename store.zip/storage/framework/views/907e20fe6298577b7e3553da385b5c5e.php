<?php echo $__env->yieldContent("js-online"); ?>
<!--=============== SWIPER JS ===============-->
<script src="<?php echo e(asset('assets/js/swiper-bundle.min.j')); ?>s"></script>

<!--=============== MAIN JS ===============-->
<script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
<?php echo $__env->yieldContent("js"); ?><?php /**PATH /home/youssef-bellouz/Downloads/My Projects/Projects-Laravel/Prestige-Watches-Store (Copy)/resources/views/Users/layouts/footer-scripts.blade.php ENDPATH**/ ?>