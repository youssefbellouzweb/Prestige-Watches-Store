<?php $__env->startSection('title'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style-online'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!--==================== MAIN ====================-->
    <main class="main">
        <!--==================== HOME ====================-->
        <section class="home" id="home">
            <div class="home__container container grid">
                <div class="home__img-bg">
                    <img src="<?php echo e(asset($product['image'])); ?>" alt="New Watch Collection" class="home__img">
                </div>

                <div class="home__social">
                    <a href="https://www.instagram.com/prestigewatches" target="_blank" class="home__social-link">
                        Instagram
                    </a>
                </div>
                <div class="home__data">
                    <h1 class="home__title">Audemars<br><?php echo e($product['title']); ?></h1>
                    <p class="home__description">
                        Discover the latest arrival of the new imported watches of the Day-Just series,
                        featuring a modern and resistant design.
                    </p>
                    <span class="home__price"><?php echo e($product['price']); ?>DH</span>

                    <div class="home__btns">
                        <a href="#featured" class="button button--gray button--small">
                            Discover
                        </a>
                        <a href="<?php echo e(route('product', ['brand_slug' => $product['brand_slug'], 'slug' => $product['title']])); ?>"
                            class="button home__button">Buy NOW </a>
                    </div>
                </div>
            </div>
        </section>
        <!--==================== FEATURED ====================-->
        <section class="featured section container" id="featured">
            <h2 class="section__title">The Clients Favourite</h2>
            <div class="featured__container grid">
                <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article class="featured__card">
                        <span class="featured__tag"><?php echo e($feature['tag']); ?></span>
                        <img src="<?php echo e(asset($feature['image'])); ?>" alt="<?php echo e($feature['alt']); ?>" class="featured__img">
                        <div class="featured__data">
                            <h3 class="featured__title"><?php echo e($feature['title']); ?></h3>
                            <span class="featured__price"><?php echo e($feature['price']); ?>DH</span>
                        </div>
                        <a href="<?php echo e(route('product', ['brand_slug' => $feature['brand_slug'], 'slug' => $feature['title']])); ?>"
                            class="button featured__button">
                            Buy
                            Now</a>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>
        <!--==================== OUR TRUSTED BRANDS ====================-->
        <section class="brands section container" id="brands">
            <h2 class="section__title">Our Trusted Brands</h2>

            <div class="brands__container grid">
                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article class="brands__card">
                        <img src="<?php echo e(asset($brand['image'])); ?>" alt="<?php echo e($brand['alt']); ?>" class="brands__img">
                        <h3 class="brands__title"><?php echo e($brand['title']); ?></h3>
                        <a href="<?php echo e(route('brand', ['slug' => $brand['slug']])); ?>"
                            class="button brands__button">Explore</a>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>
        </div>
        </section>
        <!--==================== STORY ====================-->
        <section class="story section container" id="about">
            <div class="story__container grid">
                <div class="story__data">
                    <h2 class="section__title story__section-title">
                        Our Story
                    </h2>

                    <h1 class="story__title">
                        Inspirational Watch of <br> this year
                    </h1>

                    <p class="story__description">
                    <section class="our-story">
                        <div class="container">

                            <p class="our-story__text">
                                Prestige Watches, we blend the charm of Moroccan craftsmanship with unmatched quality and
                                fair prices. Discover luxury without compromise.
                            </p>
                        </div>
                    </section>

                    </p>

                </div>

                <div class="story__images">
                    <img src="<?php echo e(asset('assets/img/Rolex/date just acier/rolex-datejust-white-arabic-dial-steel-yellow-gold-mens-watch-16233-65560_4caff.jpg')); ?>"
                        alt="" class="story__img">
                    <div class="story__square"></div>
                </div>
            </div>
        </section>
        <!--==================== PRODUCTS ====================-->
        <section class="products section container" id="products">
            <h2 class="section__title">
                Products
            </h2>

            <div class="products__container grid">

                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article class="products__card">
                        <img src="<?php echo e(asset($product['image'])); ?>" alt="<?php echo e($product['alt']); ?>" class="products__img">

                        <h3 class="products__title"><?php echo e($product['title']); ?></h3>
                        <span class="products__price"><?php echo e($product['price']); ?>DH</span>

                        <a href="<?php echo e(route('product', ['brand_slug' => $product['brand_slug'], 'slug' => $product['title']])); ?>"
                            class="products__button">
                            <i class='bx bx-shopping-bag'></i>
                        </a>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </section>
        <!--==================== NEW ARRIVALS ====================-->
        <section class="new section container" id="new">
            <h2 class="section__title">New Arrivals</h2>
            <div class="new__container">
                <div class="swiper new-swiper">
                    <div class="swiper-wrapper">
                        <?php $__currentLoopData = $watches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $watch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <article class="new__card swiper-slide">
                                <span class="new__tag"><?php echo e($watch['tag']); ?></span>

                                <img src="<?php echo e(asset($watch['image'])); ?>" alt="<?php echo e($watch['alt']); ?>" class="new__img">

                                <div class="new__data">
                                    <h3 class="new__title"><?php echo e($watch['title']); ?></h3>
                                    <span class="new__price"><?php echo e($watch['price']); ?>DH</span>
                                </div>

                                <a href="<?php echo e(route('product', ['brand_slug' => $product['brand_slug'], 'slug' => $product['title']])); ?>"
                                    class="button featured__button">
                                    BUY NOW
                                </a>
                            </article>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-online'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Users.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/youssef-bellouz/Downloads/My Projects/Projects-Laravel/Prestige-Watches-Store (Copy)/resources/views/Users/welcome.blade.php ENDPATH**/ ?>